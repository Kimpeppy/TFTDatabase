CREATE TABLE teamComps (
    teamID VARCHAR(50) PRIMARY KEY,
    participantID VARCHAR(50),
    champion_name1 VARCHAR(50),
    champion_name2 VARCHAR(50),
    champion_name3 VARCHAR(50),
    champion_name4 VARCHAR(50),
    champion_name5 VARCHAR(50),
    champion_name6 VARCHAR(50),
    champion_name7 VARCHAR(50),
    champion_name8 VARCHAR(50),
    champion_name9 VARCHAR(50),
    champion_name10 VARCHAR(50),
    champion_name11 VARCHAR(50),
    champion_name12 VARCHAR(50),
    augment_name1 VARCHAR(50),
    augment_name2 VARCHAR(50),
    augment_name3 VARCHAR(50)
)