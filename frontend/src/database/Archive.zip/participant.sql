CREATE TABLE participant (
    participantID VARCHAR(50) PRIMARY KEY,
    participantName VARCHAR(50),
CREATE TABLE participant (
    participantID VARCHAR(50) PRIMARY KEY,
    participantName VARCHAR(50),
    teamID VARCHAR(50),
    gameID VARCHAR(225)
);